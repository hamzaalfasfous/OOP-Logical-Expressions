/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hamzajava;
//hamza alfasfous 221122
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Stack;

/**
 *
 * @author hamza
 */
public abstract class Gate implements Solve {
    
    private ArrayList<String> PostFixExpressions ;
    private ArrayList<Map<String,Boolean>>variable ;

    public Gate() {
         PostFixExpressions =null;
         variable =null;
    }
        
    public Gate(ArrayList<String> PostFixExpressions, ArrayList<Map<String, Boolean>> variable) {
            setPostFixExpressions(PostFixExpressions);
            setVariable(variable);

        }

    public void setPostFixExpressions(ArrayList<String> PostFixExpressions) {
        this.PostFixExpressions = PostFixExpressions;
    }

    public void setVariable(ArrayList<Map<String, Boolean>> variable) {
        this.variable = variable;
    }

    public ArrayList<String> getPostFixExpressions() {
        return PostFixExpressions;
    }

    public ArrayList<Map<String, Boolean>> getVariable() {
        return variable;
    }

   public List<Boolean> evaluateExpressions() {
        List<Boolean> results = new ArrayList<>();
        for (String expression : PostFixExpressions) {
            Map<String, Boolean> variableValues = variable.get(PostFixExpressions.indexOf(expression));
            results.add(TheResult(expression, variableValues));
    }
    return results;
}

private Boolean TheResult(String expression, Map<String, Boolean> variableValues) {
    Stack<Boolean> evaluationStack = new Stack<>();
    for (char part : expression.toCharArray()) {
        if (Character.isLetter(part)) {
            Boolean value = variableValues.getOrDefault(String.valueOf(part), false);
            evaluationStack.push(value);
        } else {
            switch (part) {
                case '+':
                    evaluationStack.push(new OrGate().evaluate(evaluationStack.pop(), evaluationStack.pop()));
                    break;
                case '.':
                    evaluationStack.push(new AndGate().evaluate(evaluationStack.pop(), evaluationStack.pop()));
                    break;
                case '~':
                    evaluationStack.push(new NotGate().evaluate(evaluationStack.pop(), true));
                    break;
                default:
                    throw new IllegalArgumentException("Invalid letter or symbol  in expression: " + part);
            }
        }
    }
    return evaluationStack.pop();
    }   

    @Override
    public String toString() {
        return "Gate{" + "PostFixExpressions=" + PostFixExpressions + ", variable=" + variable + '}';
    }


}