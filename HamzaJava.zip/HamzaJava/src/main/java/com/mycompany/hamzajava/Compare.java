/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hamzajava;
//hamza alfasfous 221122
import java.util.ArrayList;
import java.util.Stack;

/**
 *
 * @author hamza
 */
public class Compare {
    private  ArrayList<String> postfixExpressions;

    private int getPrecedence(char operator) {
        switch (operator) {
            case '+': 
                return 1;
            case '.': 
                return 2;
            default:
                return -1;
        }
    }
    
public ArrayList<String> compareToPostFix(ArrayList<String> expressions) {
        ArrayList<String> postFixExpressions = new ArrayList<>();
        
        for (int i = 0; i < expressions.size(); i++) {
            String infix = expressions.get(i);
            String postfix = infixToPostfix(infix);
            postFixExpressions.add(postfix);
        }

        return postFixExpressions;
    }

    private String infixToPostfix(String infix) {
        StringBuilder postfix = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < infix.length(); i++) {
            char key = infix.charAt(i);

            if (Character.isLetter(key)) {
                postfix.append(key);
            } else if (key == '~') {
                i++;
                if (i < infix.length() && Character.isLetter(infix.charAt(i))) {
                    postfix.append(infix.charAt(i));
                    postfix.append('~');
                } else {
                    throw new IllegalArgumentException("Negation operator must be followed by an operand.");
                }
            } else {
                
                while (!stack.isEmpty() && getPrecedence(key) <= getPrecedence(stack.peek())) {
                    postfix.append(stack.pop());
                }
                stack.push(key);
            }
        }

        
        while (!stack.isEmpty()) {
            postfix.append(stack.pop());
        }

        return postfix.toString();
    }

    @Override
    public String toString() {
        return "Compare{" + "postfixExpressions=" + postfixExpressions + '}';
    }

    

   


}