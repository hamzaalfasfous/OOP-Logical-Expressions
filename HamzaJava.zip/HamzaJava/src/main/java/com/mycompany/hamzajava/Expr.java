/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hamzajava;
//hamza alfasfous 221122
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author hamza
 */
public class Expr {
 
  private Gate gate;
   private ArrayList<String> expressions;
   private ArrayList<Map<String,Boolean>> variable;
   public Expr() throws FileNotFoundException {
        loadData();
        initializeGate();
        processExpressions();
}

     private void loadData() throws FileNotFoundException {
        Read readData = new Read();
        setExpressions(readData);
        setVariable(readData);
    }

    private void initializeGate() {
        this.gate = new Gate() {
            @Override
            public boolean evaluate(boolean a, boolean b) {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        };
    }

    private void processExpressions() {
        ArrayList<String> preprocessedExpressions = new ArrayList<>();
        for (String expr : expressions) {
            preprocessedExpressions.add(addDot(expr));
        }

        Compare  converter = new Compare();
        ArrayList<String> postFixExpressions = converter.compareToPostFix(preprocessedExpressions);
        gate.setPostFixExpressions(postFixExpressions);
        gate.setVariable(variable);
    }
   
   
   
   private String addDot(String expression) {
    String newExpression = "";
    for (int i = 0; i < expression.length(); i++) {
        char currentChar = expression.charAt(i);
        newExpression += currentChar;  

        if (i < expression.length() - 1 && Character.isLetter(currentChar)) {
            char nextChar = expression.charAt(i + 1);
          
            if (Character.isLetter(nextChar)) {  
                newExpression += '.';  
            }
        }
    }
    return newExpression;
}

    public Expr(Gate gate, ArrayList<String> expressions, ArrayList<Map<String, Boolean>> variable) {
        this.gate = gate;
        this.expressions = expressions;
        this.variable = variable;
    }
    public Gate getGate() {
        return gate;
    }

    public void setGate(Gate gate) {
        this.gate = gate;
    }

    public void setExpressions(Read F) {
        this.expressions = F.getLines();
    }

    public void setVariable(Read F) {
        this.variable = F.getVariable();
    }

    public ArrayList<String> getExpressions() {
        return expressions;
    }

    public ArrayList<Map<String, Boolean>> getVariable() {
        return variable;
    }
    @Override
    public String toString() {
    for (int i = 0; i < expressions.size(); i++) {
        System.out.println("The result of this expression (" + expressions.get(i) + ")  is --------> " + gate.evaluateExpressions().get(i));
    }
    return "";
 }


    
    
    
            
}