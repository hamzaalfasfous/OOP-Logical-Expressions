/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hamzajava;
//hamza alfasfous 221122
import java.io.FileNotFoundException;

/**
 *
 * @author hamza
 */
public class Main {

 public static void main(String[] args) throws FileNotFoundException {

       Expr exp =new Expr();
       System.out.println(exp.toString());

    }
}
