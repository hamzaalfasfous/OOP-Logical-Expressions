/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hamzajava;
//hamza alfasfous 221122
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author hamza
 */
public class Read {
    private File file;
    private ArrayList<String> lines;
    private ArrayList<Map<String, Boolean>> variable;
    public Read() throws FileNotFoundException {
        this.file = new File("data.txt"); 
        this.lines = new ArrayList<>();
        this.variable = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(this.file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 2);    
                String expression = parts[0].trim();
                lines.add(expression);

               if (parts.length > 1) {
                    Map<String, Boolean> variable_Map = new HashMap<>();
                   for (String assignment : parts[1].split(",")) {
                        String[] entry = assignment.trim().split("=");
                        variable_Map.put(entry[0].trim(), "1".equals(entry[1].trim()));
                    }
                    variable.add(variable_Map);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Read(ArrayList<String> lines, ArrayList<Map<String, Boolean>> variable, File file) {
        this.lines = lines;
        this.variable = variable;
        this.file = file;
    }

    public void setLines(ArrayList<String> lines) {
        this.lines = lines;
    }

    public void setVariable(ArrayList<Map<String, Boolean>> variable) {
        this.variable = variable;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public ArrayList<String> getLines() {
        return lines;
    }

    public ArrayList<Map<String, Boolean>> getVariable() {
        return variable;
    }

    public File getFile() {
        return file;
    }

   
}