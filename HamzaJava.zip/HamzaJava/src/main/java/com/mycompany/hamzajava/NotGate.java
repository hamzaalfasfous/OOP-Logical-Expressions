/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hamzajava;
//hamza alfasfous 221122
/**
 *
 * @author hamza
 */
public  class NotGate extends Gate {

    @Override
    public boolean evaluate(boolean a, boolean b) {
        return !a;
    }
}